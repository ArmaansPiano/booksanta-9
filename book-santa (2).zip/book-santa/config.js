import * as firebase from 'firebase';
require('@firebase/firestore')


var firebaseConfig = {
    apiKey: "AIzaSyCkX8eB8U30Ps28mQifGeT1DfewQHNTNZA",
    authDomain: "boksanta-bc83b.firebaseapp.com",
    projectId: "boksanta-bc83b",
    storageBucket: "boksanta-bc83b.appspot.com",
    messagingSenderId: "246407804783",
    appId: "1:246407804783:web:ee763c26efcd3e2d881a9a",
    measurementId: "G-FKYX2G8KSY"
  };

if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
 }
  export default firebase.firestore
